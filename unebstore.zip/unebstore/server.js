const express = require('express');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());
const upload = multer({ dest: 'uploads/' });

// Configuração do MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // nome de usuário
    password: '29122001', // senha do mysql
    database: 'une_store' // nome do banco de dados
});

db.connect((err) => {
    if (err) {
        console.error('Erro de conexão com o banco de dados:', err); // Log de erro
        throw err;
    }
    console.log('Conectado ao banco de dados.');
});


// Middleware para autenticação
function authenticateToken(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Acesso negado.' });

    jwt.verify(token, 'sua_chave_secreta', (err, user) => { // Substitua pela chave secreta correta
        if (err) return res.status(403).json({ message: 'Token inválido.' });
        req.user = user;
        next();
    });
}

// Rota de Cadastro
app.post('/auth/cadastro', async (req, res) => {
    const { nome, matricula, telefone, senha, tipo_usuario, curso, funcao } = req.body;

    // Validar os dados recebidos
    if (!nome || !matricula || !telefone || !senha || !tipo_usuario) {
        return res.status(400).json({ message: 'Preencha todos os campos!' });
    }

    if (tipo_usuario === 'aluno' && !curso) {
        return res.status(400).json({ message: 'Preencha o campo curso para alunos!' });
    }

    if (tipo_usuario === 'funcionario' && !funcao) {
        return res.status(400).json({ message: 'Preencha o campo função para funcionários!' });
    }

    try {
        const hashedPassword = await bcrypt.hash(senha, 10);

        db.query('INSERT INTO users SET ?', {
            nome,
            matricula,
            telefone,
            senha: hashedPassword,
            tipo_usuario,
            curso: curso || null,
            funcao: funcao || null
        }, (err, results) => {
            if (err) {
                console.error('Erro ao cadastrar usuário:', err.code, err.sqlMessage);
                return res.status(400).json({ message: 'Erro ao cadastrar.', error: err.sqlMessage });
            }
            res.status(201).json({ message: 'Cadastro realizado com sucesso!' });
        });
    } catch (error) {
        console.error('Erro no hash da senha:', error);
        return res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});


// Rota de Login
app.post('/auth/login', (req, res) => {
    const { matricula, senha } = req.body;

    db.query('SELECT * FROM users WHERE matricula = ?', [matricula], async (err, results) => {
        if (err || results.length === 0) return res.status(400).json({ message: 'Usuário não encontrado.' });

        const user = results[0];
        if (!(await bcrypt.compare(senha, user.senha))) {
            return res.status(400).json({ message: 'Senha incorreta.' });
        }

        const token = jwt.sign({ id: user.id, matricula: user.matricula }, 'sua_chave_secreta'); // Substitua pela chave secreta correta
        res.json({ token });
    });
});

// Rota para Adicionar Produto
app.post('/produtos/adicionar', authenticateToken, upload.array('fotos'), (req, res) => {
    const { nome, categoria, condicao, descricao, preco } = req.body;
    const user_id = req.user.id;
    const imagens = req.files.map((file) => file.path).join(',');

    db.query('INSERT INTO products SET ?', {
        user_id, nome, categoria, condicao, descricao, preco, imagens
    }, (err) => {
        if (err) return res.status(400).json({ message: 'Erro ao adicionar produto.' });
        res.json({ message: 'Produto adicionado com sucesso!' });
    });
});

// Rota para Listar Produtos
app.get('/produtos/todos', (req, res) => {
    db.query('SELECT * FROM products', (err, results) => {
        if (err) return res.status(400).json({ message: 'Erro ao buscar produtos.' });
        res.json(results);
    });
});

// Rota para Curtir Produto
app.post('/produtos/:id/curtir', authenticateToken, (req, res) => {
    const { id: product_id } = req.params;
    const user_id = req.user.id;

    db.query('INSERT INTO likes SET ?', { user_id, product_id }, (err) => {
        if (err) return res.status(400).json({ message: 'Erro ao curtir produto.' });
        res.json({ message: 'Produto curtido com sucesso!' });
    });
});

// Rota para Excluir Produto
app.delete('/produtos/:id', authenticateToken, (req, res) => {
    const { id: product_id } = req.params;
    const user_id = req.user.id;

    db.query('DELETE FROM products WHERE id = ? AND user_id = ?', [product_id, user_id], (err, results) => {
        if (err || results.affectedRows === 0) return res.status(400).json({ message: 'Erro ao excluir produto.' });
        res.json({ message: 'Produto excluído com sucesso!' });
    });
});

// Rota de Chat
app.post('/chats/enviar', authenticateToken, (req, res) => {
    const { buyer_id, seller_id, product_id, mensagem } = req.body;

    db.query('INSERT INTO chats SET ?', { buyer_id, seller_id, product_id, mensagem }, (err) => {
        if (err) return res.status(400).json({ message: 'Erro ao enviar mensagem.' });
        res.json({ message: 'Mensagem enviada com sucesso!' });
    });
});

// Iniciar Servidor
app.listen(3000, () => {
    console.log('Servidor rodando na porta 3000');
});
